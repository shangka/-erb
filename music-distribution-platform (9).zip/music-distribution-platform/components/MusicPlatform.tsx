'use client'

import React, { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Home, Music, BarChart2, Upload, DollarSign, Globe } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { Notification } from './Notification'

export default function MusicPlatform() {
  const [activeTab, setActiveTab] = useState('overview')
  const [songs, setSongs] = useState([])
  const [file, setFile] = useState(null)
  const [coverArt, setCoverArt] = useState(null)
  const [title, setTitle] = useState('')
  const [artist, setArtist] = useState('')
  const [notification, setNotification] = useState(null)
  const router = useRouter()

  useEffect(() => {
    fetchSongs()
  }, [])

  const fetchSongs = async () => {
    try {
      const res = await fetch('/api/songs', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      if (res.ok) {
        const data = await res.json()
        setSongs(data)
      } else {
        throw new Error('Failed to fetch songs')
      }
    } catch (error) {
      console.error('Error fetching songs:', error)
      setNotification({ type: 'error', message: '获取歌曲列表失败' })
    }
  }

  const handleUpload = async (e) => {
    e.preventDefault()
    if (!file || !title || !artist) {
      setNotification({ type: 'error', message: '请选择音频文件、输入标题和艺术家名称' })
      return
    }

    try {
      // Get presigned URL for audio file
      const audioRes = await fetch(`/api/upload-url?fileName=${file.name}&fileType=${file.type}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      if (!audioRes.ok) {
        throw new Error('Failed to get audio upload URL')
      }
      const { uploadUrl: audioUploadUrl, key: audioKey } = await audioRes.json()

      // Upload audio file to S3
      const audioUploadRes = await fetch(audioUploadUrl, {
        method: 'PUT',
        body: file,
        headers: {
          'Content-Type': file.type,
        },
      })
      if (!audioUploadRes.ok) {
        throw new Error('Failed to upload audio file')
      }

      let coverArtKey = null
      if (coverArt) {
        // Get presigned URL for cover art
        const coverRes = await fetch(`/api/upload-url?fileName=${coverArt.name}&fileType=${coverArt.type}`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })
        if (!coverRes.ok) {
          throw new Error('Failed to get cover art upload URL')
        }
        const { uploadUrl: coverUploadUrl, key: coverKey } = await coverRes.json()

        // Upload cover art to S3
        const coverUploadRes = await fetch(coverUploadUrl, {
          method: 'PUT',
          body: coverArt,
          headers: {
            'Content-Type': coverArt.type,
          },
        })
        if (!coverUploadRes.ok) {
          throw new Error('Failed to upload cover art')
        }
        coverArtKey = coverKey
      }

      // Create song in database
      const songRes = await fetch('/api/songs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          title,
          artist,
          fileUrl: `https://${process.env.NEXT_PUBLIC_AWS_S3_BUCKET_NAME}.s3.amazonaws.com/${audioKey}`,
          coverArtUrl: coverArtKey ? `https://${process.env.NEXT_PUBLIC_AWS_S3_BUCKET_NAME}.s3.amazonaws.com/${coverArtKey}` : null,
        }),
      })

      if (songRes.ok) {
        setFile(null)
        setCoverArt(null)
        setTitle('')
        setArtist('')
        fetchSongs()
        setNotification({ type: 'success', message: '歌曲上传成功' })
      } else {
        throw new Error('Failed to create song')
      }
    } catch (error) {
      console.error('Error during upload:', error)
      setNotification({ type: 'error', message: '上传失败：' + error.message })
    }
  }

  const handleRelease = async (songId) => {
    try {
      const res = await fetch('/api/releases', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ songId }),
      })
      if (res.ok) {
        fetchSongs()
        setNotification({ type: 'success', message: '发行已开始处理' })
      } else {
        throw new Error('Failed to create release')
      }
    } catch (error) {
      console.error('Error creating release:', error)
      setNotification({ type: 'error', message: '发行失败：' + error.message })
    }
  }

  const checkReleaseStatus = async (releaseId) => {
    try {
      const res = await fetch(`/api/releases/${releaseId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      if (res.ok) {
        const release = await res.json()
        setNotification({ type: 'success', message: `发行状态：${release.status}` })
        fetchSongs()
      } else {
        throw new Error('Failed to check release status')
      }
    } catch (error) {
      console.error('Error checking release status:', error)
      setNotification({ type: 'error', message: '检查发行状态失败：' + error.message })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      <header className="bg-gray-800 shadow-lg">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-3xl font-bold text-white flex items-center">
            <Globe className="mr-2" /> 耳边科技全球音乐发行平台
          </h1>
          <Button onClick={() => router.push('/login')} variant="outline">登出</Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {notification && (
          <Notification type={notification.type} message={notification.message} />
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-5 gap-4 bg-gray-700 p-1 rounded-lg">
            <TabsTrigger value="overview" className="data-[state=active]:bg-gray-600">
              <Home className="mr-2 h-4 w-4" /> 首页
            </TabsTrigger>
            <TabsTrigger value="songs" className="data-[state=active]:bg-gray-600">
              <Music className="mr-2 h-4 w-4" /> 音乐
            </TabsTrigger>
            <TabsTrigger value="data" className="data-[state=active]:bg-gray-600">
              <BarChart2 className="mr-2 h-4 w-4" /> 数据
            </TabsTrigger>
            <TabsTrigger value="upload" className="data-[state=active]:bg-gray-600">
              <Upload className="mr-2 h-4 w-4" /> 上传
            </TabsTrigger>
            <TabsTrigger value="finance" className="data-[state=active]:bg-gray-600">
              <DollarSign className="mr-2 h-4 w-4" /> 财务
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl text-white">欢迎来到耳边科技全球音乐发行平台</CardTitle>
                <CardDescription className="text-gray-400">在这里，您可以管理您的音乐、发行到全球流媒体平台、查看数据分析，并处理您的收益。</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 mb-4">我们支持发行到以下全球流媒体平台：</p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {['Spotify', 'Apple Music', 'YouTube Music', 'Amazon Music', 'Deezer', 'Tidal', '网易云音乐', 'QQ音乐', 'Yandex Music', 'Anghami'].map((platform) => (
                    <div key={platform} className="bg-gray-700 rounded-lg p-4 text-center">
                      <p className="text-sm font-medium">{platform}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="songs">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl text-white">您的音乐</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {songs.map((song) => (
                    <div key={song.id} className="bg-gray-700 rounded-lg p-4 flex items-center space-x-4">
                      {song.coverArtUrl && (
                        <img src={song.coverArtUrl} alt={song.title} className="w-20 h-20 object-cover rounded-lg" />
                      )}
                      <div className="flex-grow">
                        <h3 className="text-lg font-semibold">{song.title}</h3>
                        <p className="text-gray-400">{song.artist}</p>
                        {song.releases && song.releases.length > 0 ? (
                          <div className="mt-2">
                            <span className="text-gray-300">发行状态: {song.releases[0].status}</span>
                            <Button onClick={() => checkReleaseStatus(song.releases[0].id)} variant="outline" size="sm" className="ml-2">
                              检查状态
                            </Button>
                          </div>
                        ) : (
                          <Button onClick={() => handleRelease(song.id)} variant="outline" size="sm" className="mt-2">
                            发行到全球流媒体平台
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="data">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl text-white">数据分析</CardTitle>
                <CardDescription className="text-gray-400">查看您音乐的表现数据</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">这里将显示您的音乐在各个流媒体平台上的表现数据。</p>
                {/* 这里可以添加图表或数据可视化组件 */}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="upload">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl text-white">上传音乐</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpload} className="space-y-4">
                  <div>
                    <label htmlFor="audio-file" className="block text-sm font-medium text-gray-300 mb-1">
                      音频文件
                    </label>
                    <Input
                      id="audio-file"
                      type="file"
                      onChange={(e) => setFile(e.target.files[0])}
                      accept="audio/*"
                      className="bg-gray-700 text-white border-gray-600"
                    />
                  </div>
                  <div>
                    <label htmlFor="cover-art" className="block text-sm font-medium text-gray-300 mb-1">
                      封面图片（可选）
                    </label>
                    <Input
                      id="cover-art"
                      type="file"
                      onChange={(e) => setCoverArt(e.target.files[0])}
                      accept="image/*"
                      className="bg-gray-700 text-white border-gray-600"
                    />
                  </div>
                  <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-1">
                      歌曲标题
                    </label>
                    <Input
                      id="title"
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="输入歌曲标题"
                      className="bg-gray-700 text-white border-gray-600"
                    />
                  </div>
                  <div>
                    <label htmlFor="artist" className="block text-sm font-medium text-gray-300 mb-1">
                      艺术家
                    </label>
                    <Input
                      id="artist"
                      type="text"
                      value={artist}
                      onChange={(e) => setArtist(e.target.value)}
                      
                      placeholder="输入艺术家名称"
                      className="bg-gray-700 text-white border-gray-600"
                    />
                  </div>
                  <Button type="submit" className="w-full">上传</Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="finance">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-2xl text-white">财务管理</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">这里将显示您的全球收益信息和管理选项。</p>
                {/* 这里可以添加财务数据和管理选项 */}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}