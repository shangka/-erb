import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '../../../lib/prisma'
import { authenticateToken } from '../../../lib/auth'
import axios from 'axios'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await authenticateToken(req, res)
  if (!user) return

  if (req.method === 'POST') {
    const { songId } = req.body

    if (!songId) {
      return res.status(400).json({ error: 'Song ID is required' })
    }

    try {
      const song = await prisma.song.findUnique({
        where: { id: songId, userId: user.id },
      })

      if (!song) {
        return res.status(404).json({ error: 'Song not found' })
      }

      // Integrate with DistroKid API
      const distroKidResponse = await axios.post(
        'https://distrokid.com/api/v1/release',
        {
          title: song.title,
          artist: song.artist,
          audioFile: song.fileUrl,
          coverArt: song.coverArtUrl,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.DISTROKID_API_KEY}`,
          },
        }
      )

      const release = await prisma.release.create({
        data: {
          songId,
          status: 'pending',
          distroKidReleaseId: distroKidResponse.data.releaseId,
        },
      })

      res.status(201).json(release)
    } catch (error) {
      console.error('Error creating release:', error)
      res.status(500).json({ error: 'Internal server error' })
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' })
  }
}