'use client'

import React, { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Home, Music, BarChart2, Upload, DollarSign } from 'lucide-react'

export default function MusicPlatform() {
  const [activeTab, setActiveTab] = useState('overview')
  const [songs, setSongs] = useState([])
  const [title, setTitle] = useState('')
  const [artist, setArtist] = useState('')

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault()
    if (title && artist) {
      setSongs([...songs, { id: Date.now(), title, artist, status: 'pending' }])
      setTitle('')
      setArtist('')
    }
  }

  const handleRelease = (id: number) => {
    setSongs(songs.map(song => 
      song.id === id ? { ...song, status: 'released' } : song
    ))
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-bold text-center mb-8">耳边科技全球音乐发行平台</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="overview" className="flex items-center">
            <Home className="mr-2 h-4 w-4" /> 首页
          </TabsTrigger>
          <TabsTrigger value="songs" className="flex items-center">
            <Music className="mr-2 h-4 w-4" /> 音乐
          </TabsTrigger>
          <TabsTrigger value="data" className="flex items-center">
            <BarChart2 className="mr-2 h-4 w-4" /> 数据
          </TabsTrigger>
          <TabsTrigger value="upload" className="flex items-center">
            <Upload className="mr-2 h-4 w-4" /> 上传
          </TabsTrigger>
          <TabsTrigger value="finance" className="flex items-center">
            <DollarSign className="mr-2 h-4 w-4" /> 财务
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>欢迎来到耳边科技全球音乐发行平台</CardTitle>
              <CardDescription>在这里，您可以管理您的音乐、发行到全球流媒体平台、查看数据分析，并处理您的收益。</CardDescription>
            </CardHeader>
            <CardContent>
              <p>我们支持发行到多个全球流媒体平台，包括Spotify、Apple Music、YouTube Music等。</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="songs">
          <Card>
            <CardHeader>
              <CardTitle>您的音乐</CardTitle>
            </CardHeader>
            <CardContent>
              <ul>
                {songs.map((song) => (
                  <li key={song.id} className="mb-4 p-4 border border-gray-200 rounded-lg">
                    <h3 className="text-lg font-semibold">{song.title} - {song.artist}</h3>
                    <p>状态: {song.status}</p>
                    {song.status === 'pending' && (
                      <Button onClick={() => handleRelease(song.id)} className="mt-2">
                        发行到全球流媒体平台
                      </Button>
                    )}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data">
          <Card>
            <CardHeader>
              <CardTitle>数据分析</CardTitle>
              <CardDescription>查看您音乐的表现数据</CardDescription>
            </CardHeader>
            <CardContent>
              <p>这里将显示您的音乐数据分析。</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload">
          <Card>
            <CardHeader>
              <CardTitle>上传音乐</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleUpload}>
                <Input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="歌曲标题"
                  className="mb-4"
                />
                <Input
                  type="text"
                  value={artist}
                  onChange={(e) => setArtist(e.target.value)}
                  placeholder="艺术家"
                  className="mb-4"
                />
                <Button type="submit">上传</Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="finance">
          <Card>
            <CardHeader>
              <CardTitle>财务管理</CardTitle>
            </CardHeader>
            <CardContent>
              <p>这里将显示您的财务信息和管理选项。</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}