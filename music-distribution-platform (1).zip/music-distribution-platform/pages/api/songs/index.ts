import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '../../../lib/prisma'
import { authenticateToken } from '../../../lib/auth'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await authenticateToken(req, res)
  if (!user) return

  if (req.method === 'GET') {
    try {
      const songs = await prisma.song.findMany({
        where: { userId: user.id },
        include: { releases: true },
      })
      res.status(200).json(songs)
    } catch (error) {
      console.error('Error fetching songs:', error)
      res.status(500).json({ error: 'Internal server error' })
    }
  } else if (req.method === 'POST') {
    const { title, artist, fileUrl, coverArtUrl } = req.body

    if (!title || !artist || !fileUrl) {
      return res.status(400).json({ error: 'Title, artist, and file URL are required' })
    }

    try {
      const song = await prisma.song.create({
        data: {
          title,
          artist,
          fileUrl,
          coverArtUrl,
          userId: user.id,
        },
      })
      res.status(201).json(song)
    } catch (error) {
      console.error('Error creating song:', error)
      res.status(500).json({ error: 'Internal server error' })
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' })
  }
}