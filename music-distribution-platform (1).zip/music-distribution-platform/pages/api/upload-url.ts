import { NextApiRequest, NextApiResponse } from 'next'
import { authenticateToken } from '../../lib/auth'
import { getSignedUrl } from '../../lib/s3'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await authenticateToken(req, res)
  if (!user) return

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  const { fileName, fileType } = req.query

  if (!fileName || !fileType) {
    return res.status(400).json({ error: 'File name and type are required' })
  }

  try {
    const key = `${user.id}/${fileName}`
    const signedUrl = await getSignedUrl(key, fileType as string)
    res.status(200).json({ uploadUrl: signedUrl, key })
  } catch (error) {
    console.error('Error generating signed URL:', error)
    res.status(500).json({ error: 'Internal server error' })
  }
}