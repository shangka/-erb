import MusicPlatform from '../components/MusicPlatform'

export default function Home() {
  return (
    <main>
      <MusicPlatform />
    </main>
  )
}