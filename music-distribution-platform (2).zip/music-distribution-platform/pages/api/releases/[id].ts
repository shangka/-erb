import { NextApiRequest, NextApiResponse } from 'next'
import prisma from '../../../lib/prisma'
import { authenticateToken } from '../../../lib/auth'
import axios from 'axios'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await authenticateToken(req, res)
  if (!user) return

  const { id } = req.query

  if (req.method === 'GET') {
    try {
      const release = await prisma.release.findUnique({
        where: { id: id as string },
        include: { song: true },
      })

      if (!release) {
        return res.status(404).json({ error: 'Release not found' })
      }

      if (release.song.userId !== user.id) {
        return res.status(403).json({ error: 'Unauthorized' })
      }

      // Check status with DistroKid API
      const distroKidResponse = await axios.get(
        `https://distrokid.com/api/v1/release/${release.distroKidReleaseId}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.DISTROKID_API_KEY}`,
          },
        }
      )

      const updatedRelease = await prisma.release.update({
        where: { id: id as string },
        data: { status: distroKidResponse.data.status },
      })

      res.status(200).json(updatedRelease)
    } catch (error) {
      console.error('Error checking release status:', error)
      res.status(500).json({ error: 'Internal server error' })
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' })
  }
}