import { NextApiRequest, NextApiResponse } from 'next'
import { getPresignedUrl } from '../../lib/s3'
import { authenticateToken } from '../../lib/auth'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const user = await authenticateToken(req, res)
  if (!user) return

  if (req.method === 'GET') {
    const { fileName, fileType } = req.query

    if (!fileName || !fileType) {
      return res.status(400).json({ error: 'File name and type are required' })
    }

    try {
      const key = `${user.id}/${Date.now()}-${fileName}`
      const uploadUrl = await getPresignedUrl(key, fileType as string)
      res.status(200).json({ uploadUrl, key })
    } catch (error) {
      console.error('Error generating presigned URL:', error)
      res.status(500).json({ error: 'Failed to generate upload URL' })
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' })
  }
}